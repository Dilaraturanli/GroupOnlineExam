<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>

<?php
 include("database.php"); 
if($_POST["editcourse"]){
	//$length=count($course);
	 $coursename=$_POST["coursename"];
     $coursecode=$_POST["coursecode"];
	 $courseid=$_POST["courseid"];
	  $coursecredit=$_POST["coursecredit"];

	$s=mysql_query("UPDATE course SET course_name='$coursename' WHERE course_id=$courseid");
	$s=mysql_query("UPDATE course SET  course_code=$coursecode WHERE course_id=$courseid");
	$s=mysql_query("UPDATE course SET course_credit=$coursecredit WHERE course_id=$courseid");

	echo "<center><u><b>The course successfully edited</b></u><br>
	
	<a href=editcourse_index.php>Turn Back</a></center>";
  
 }
 
?>

