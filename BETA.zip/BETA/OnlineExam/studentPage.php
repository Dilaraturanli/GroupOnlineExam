<?php
include "functions.php";
session_start();
if(isset($_SESSION["logged_user_role"]))
{
    switch($_SESSION["logged_user_role"])
    {
        case "Instructor":
            header ('Location: mainPage.php');
            setcookie("forbiddenPage", "forbiddenPage", time() + (2));
            break;
        
    }
}
elseif(!isset($_SESSION["logged_user_role"]))
{
    header('Location: loginPage.php');
    setcookie("loginFirst", "loginFirst" , time() + (2));
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <script src="js/jquery-1.12.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/exam.css">
        <title>Online Exam System</title>
    </head>
    <body>
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Online Exam System</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="mainPage.php">MainPage</a></li>
                        <li><a href="courseStudentPage.php">My Courses</a></li>
                        <li><a href="examPage.php">Exam</a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <?php
                        if(isset($_SESSION["logged_user_username"]) && isset($_SESSION["logged_user_password"]) && isset($_SESSION["logged_user_role"]))
                        {
                            $personalPageLink="#";
                            switch ($_SESSION["logged_user_role"])
                            {
                                case "Instructor":
                                    $personalPageLink = "instructorPage.php";
                                    break;
                                case "Student":
                                    $personalPageLink = "studentPage.php";
                                    break;
                            }
                            ?>
                            <li class="active">
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>
                                    Welcome <b> <?php echo $_SESSION["logged_user_username"] ?> <span class="caret"></span></b></a>
                                <ul class="dropdown-menu">
                                    <li class="active"><a href="<?php echo $personalPageLink; ?>"> Personal</a></li>
                                    <li><a href="changeStudentPass.php"> Change Password</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="logoutt.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
                            </li>
                            <?php
                        }
                        ?>
                    </ul>
                </div>
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    
                </button>
            </div>
        </nav>
        <div class="container">
            <div class="container-fluid">
                <div class="page-header">
                    <h2>Welcome Online Exam System</h2>
                </div>
            </div>
        </div>
    </body>
</html>    
