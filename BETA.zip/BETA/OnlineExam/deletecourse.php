<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>

<?php
if($_POST["deletecourse"]){
 $course=$_POST["course"];

	$length=count($course);
	
	   include("database.php"); 
	    

     for($i=0; $i<$length;$i++){
		 $question=mysql_query("DELETE FROM hasQuestion WHERE course_id)=$course[$i] ");
		 $exam=mysql_query("DELETE FROM hasExam WHERE course_id)=$course[$i]");
		$id= mysql_query("DELETE FROM  hascourse WHERE course_id=$course[$i]");
		$course= mysql_query("DELETE FROM  course WHERE course_id=$course[$i]");
	 }
 }
	echo "<center><u><b>The course successfully deleted</b></u><br><a href=deletecourse_index.php>Turn Back</a></center>";
  
 
 
?>