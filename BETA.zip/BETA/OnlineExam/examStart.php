<?php
include "functions.php";
session_start();
if(isset($_SESSION["logged_user_role"]))
{
    switch($_SESSION["logged_user_role"])
    {
        case "Instructor":
            header('Location: mainPage.php');
            setcookie("forbiddenPage" , "forbiddenPage" , time() + (2));
            break;
    }
}
elseif(!isset($_SESSION["logged_user_role"]))
{
    header('Location: loginPage.php');
    setcookie("loginFirst" , "loginFirst" , time() + (2));
}
$ques=getQuestions()
?>
<!DOCTYPE html>
    <html>
        <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <script src="js/jquery-1.12.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/exam.css">
        <title>Online Exam System</title>
        </head>
        <body>
            <div class="container">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-4">
                                        <div class="h6">
                                            <?php echo $row["course_name"]; ?>
                                        </div>
                                    </div>
                    </div>
                    
                </div>
        </div>
            
        </body>
    </html>