<?php 

include("database.php");
ob_start();
session_start();


if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}
?>
<?php
 $user=$_POST["user"];
 $length=count($user);
 if($length!=1){
	echo '<meta HTTP-EQUIV="REFRESH" content="0; url=http://localhost/onlineexam/edituser_index.php">';
	
	}
  $id=mysql_query("select user_id from user where user_id=$user[0]");
 $id=mysql_fetch_array($id);
 $id=$id[0];
 
  $un=mysql_query("select user_username from user where user_id=$user[0]");
 $un=mysql_fetch_array($un);
 $username=$un[0];
 
 $n=mysql_query("select user_name from user where user_id=$user[0]");
 $n=mysql_fetch_array($n);
 $name=$n[0];
 
 $sn=mysql_query("select user_surname from user where user_id=$user[0]");
 $sn=mysql_fetch_array($sn);
 $surname=$sn[0];
 
  $e=mysql_query("select user_email from user where user_id=$user[0]");
 $e=mysql_fetch_array($e);
 $email=$e[0];
 
   $r=mysql_query("select user_role from user where user_id=$user[0]");
 $r=mysql_fetch_array($r);
 $role=$r[0];
 
 
 
 
 ?> 
 
 
 <head>
  <title>Online Exam System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
 <div class="addform">
        <div class="panel panel-default">
            <div class="panel-body">
                <h3 class="baslik">Edit User</h3>
                <form role="form"  action="editu.php" method="POST">
                    <div class="form-group">
					<label>User ID</label>
					<input readonly="readonly" type="text" name="userid" class="form-control" value="<?php echo $id ?>" >

                
					<label>User Name</label>
                         <input  type="text" name="username" class="form-control" value="<?php echo $username ?>" >
						 
                        <label>First Name</label>
                        <input type="text" name="firstname" class="form-control" value="<?php echo $name ?>" >
						<label>Last Name</label>
                        <input type="text" name="lastname" class="form-control" value="<?php echo $surname ?>" >
						<label>Email</label>
                        <input type="text" name="email" class="form-control" value="<?php echo $email ?>" >
                      
					  
					  
					   <label>Role</label>
                         <select name="userrole" >
                       <option value="c"><?php echo $role?></option> 
					   <option value="1">1</option> 
					   <option value="2">2</option> 
                      </select>  	
                 <input type="submit" name="editcourse" class="btn btn-primary" value="Edit">					  
   </div>



                </form>




            </div>
        </div>
    </div>
	
</body>
</html>
 

