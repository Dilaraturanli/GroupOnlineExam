<?php 

include("database.php");
ob_start();
session_start();


if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}
?>

<?php
 

 $course=$_POST["course"];
 $length=count($course);
 if($length!=1){
	echo '<meta HTTP-EQUIV="REFRESH" content="0; url=http://localhost/onlineexam/editcourse_index.php">';
		
	}
 	
  $id=mysql_query("select course_id from course where course_id=$course[0]");
 $id=mysql_fetch_array($id);
 $id=$id[0];
  $n=mysql_query("select course_name from course where course_id=$course[0]");
 $n=mysql_fetch_array($n);
 $name=$n[0];
 $c=mysql_query("select course_code from course where course_id=$course[0]");
 $c=mysql_fetch_array($c);
 $code=$c[0];
 $cr=mysql_query("select course_credit from course where course_id=$course[0]");
 $cr=mysql_fetch_array($cr);
 $credit=$cr[0];
 
 ?> 
 
 
 <head>
  <title>Online Exam System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
 <div class="addform">
        <div class="panel panel-default">
            <div class="panel-body">
                <h3 class="baslik">Edit Course</h3>
                <form role="form"  action="editc.php" method="POST">
                    <div class="form-group">
					<label>Course ID</label>
					<input readonly="readonly" type="text" name="courseid" class="form-control" value="<?php echo $id ?>" >

					<label>Course Name</label>
                         <input  type="text" name="coursename" class="form-control" value="<?php echo $name ?>" >
                        <label>Course Code</label>
                        <input type="text" name="coursecode" class="form-control" value="<?php echo $code ?>" >
                      
					   <label>Course Credit</label>
                         <select name="coursecredit" >
                       <option value="c"><?php echo $credit?></option> 
					   <option value="1">1</option> 
					   <option value="2">2</option> 
					   <option value="3">3</option> 
					   <option value="4">4</option>
                      </select>  	
                 <input type="submit" name="editcourse" class="btn btn-primary" value="Edit">					  
   </div>



                </form>




            </div>
        </div>
    </div>
	
</body>
</html>
 

