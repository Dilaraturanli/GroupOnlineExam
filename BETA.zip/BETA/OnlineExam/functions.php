<?php
function databaseConnection()
{
    $servername = "localhost:3306";
    $username = "root";
    $password = "";

    $conn=mysqli_connect($servername, $username, $password, "examonline");


    mysqli_set_charset($conn, 'utf8');

    if (!$conn) {
        die("Connection failed");
    } else {
        return $conn;
    }

}
function getRoles()
{
    $con = databaseConnection();

    $sql = "SELECT * FROM role";
    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) > 0) {
        return $result;
    }

    mysqli_close($con);
}
function getStudentCourse($studentName)
{
    $con=databaseConnection();
    $_studentName= mysqli_real_escape_string($con,$studentName);
    $sql="SELECT c.course_name, c.course_code,  c.course_credit, h.hasCourse_id, c.course_id FROM course as c , hasCourse h, user as u WHERE h.course_id=c.course_id AND h.user_id=u.user_id AND u.user_username='".$_studentName."' ORDER BY h.hasCourse_id";
    $result= mysqli_query($con,$sql);
    if(mysqli_num_rows($result)>0)
    {
        return $result;
    }
    mysqli_close($con);
}
function getInstructorCourse($instructorName)
{
	 $con=databaseConnection();
    
	$sql="SELECT c.course_name, c.course_id FROM course as c, hasCourse as h, user as u WHERE h.course_id=c.course_id AND h.user_id=u.user_id AND u.user_username='".$instructorName."'";
	$result=mysqli_query($con, $sql);
	if(mysqli_num_rows($result)>0)
	{
		return $result;
	}
	mysql_close($con);
}

function getQuestions($course)
{
    $con=databaseConnection();
    $sql="SELECT q.question_text, q.question_ans1, q.question_ans2,  q.question_ans3,  q.question_ans4 , q.question_num FROM question as q, course as c, hasQuestion as h WHERE h.question_id=q.question_num AND h.course_id=c.course_id AND c.course_id='".$course."'";
    $result=mysqli_query($con,$sql);
    if(mysqli_num_rows($result)>0)
    {
        return $result;
    }
    mysql_close($con);
}



function selectCourse($courseID)
{
    $con=databaseConnection();
    header('Location: quizPage.php');
    $result=$courseID;
    
    return $result;
    
    
}
function addQuestion($courseId)
{
    $con=databaseConnection();
    
}
function getExamName()
{
    $con = databaseConnection();

    $sql = "SELECT * FROM exam";

    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) > 0) {
        return $result;
    }

    mysqli_close($con);
}
function saveQuestion($courseName, $examType, $questionNum,  $examQuestion, $examAns1, $examAns2, $examAns3, $examAns4)
{
 $con=databaseConnection();
 $_courseName=mysqli_real_escape_string($con,$courseName);
 $_examType=mysqli_real_escape_string($con,$examType);
 $_questionNum=mysqli_real_escape_string($con,$questionNum);
 $_examQuestion=mysqli_real_escape_string($con,$examQuestion);
 $_examAns1=mysqli_real_escape_string($con,$examAns1);
 $_examAns2=mysqli_real_escape_string($con,$examAns2);
 $_examAns3=mysqli_real_escape_string($con,$examAns3);
 $_examAns4=mysqli_real_escape_string($con,$examAns4);
 
 
 
$sql="INSERT into question(question_id, question_num, question_text, question_ans1, question_ans2, question_ans3, question_ans4 ) VALUES (NULL, '".$_questionNum."', '".$_examQuestion."', '".$_examAns1."','".$_examAns2."', '".$_examAns3."', '".$_examAns4."')";
 
 $sql2="INSERT into hasExam(hasExam_id, course_id, exam_id) VALUES(NULL, '".$_courseName."','" .$examType."')";
 $sql3="INSERT into hasQuestion(hasQuestion_id, course_id, question_id) VALUES (NULL, '".$_courseName."' , '".$_questionNum."')";
if(mysqli_query($con,$sql) && mysqli_query($con,$sql2) && mysqli_query($con,$sql3) )
{
   
    header('Location: addExamPage.php');
    setcookie("successAdd","successAdd",time() + (2));
    
}
else
{
    header('Location: instructorPage.php');
    
}
mysqli_close($con);
}







if($_SERVER["REQUEST_METHOD"]=="POST" && isset($_POST["courseName"]) && isset($_POST["examType"]) && isset($_POST["questionNum"])  && isset($_POST["examQuestion"]) && isset($_POST["examAns1"]) && isset($_POST["examAns2"]) && isset($_POST["examAns3"]) && isset($_POST["examAns4"]) && isset($_POST["addQuestion"]))
{
    if(!empty($_POST["courseName"]) && !empty($_POST["examType"]) && !empty($_POST["questionNum"]) &&  !empty($_POST["examQuestion"]) && !empty($_POST["examAns1"]) && !empty($_POST["examAns2"]) && !empty($_POST["examAns3"]) && !empty($_POST["examAns4"]))
    {
        saveQuestion($_POST["courseName"], $_POST["examType"], $_POST["questionNum"], $_POST["examQuestion"], $_POST["examAns1"], $_POST["examAns2"] , $_POST["examAns3"], $_POST["examAns4"]);
    }
    else
    {
        header('Location: addExamPage.php');
        
    }
}
if($_SERVER["REQUEST_METHOD"]=="POST" && isset($_POST["courseID"]) && isset($_POST["selectCourse"]))
{
    selectCourse($_POST["courseID"]);
}




function startTheExam($courselist)
{
    
   header('Location: examStart.php');
   
}



if($_SERVER["REQUEST_METHOD"]=="POST" && isset($_POST["courseList"]) && isset($_POST["startExam"]))
{
    startTheExam($_POST["courseList"]);
}




