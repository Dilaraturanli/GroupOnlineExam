<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>


<head>
<title>Online Exam System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
 <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" >Online Exam Admin System</a>
    </div>
	<div class="collapse navbar-collapse">
    <ul class="nav navbar-nav">
      <li class="active"><a href="home_index.php">Main Page</a></li>
	   <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="http://localhost/onlineexam/addUser.php">Add
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="adduser_index.php">User</a></li>
          <li><a href="addcourse_index.php">Course</a></li>
        </ul>
      </li>
      <li class="dropdown">
	   <a class="dropdown-toggle" data-toggle="dropdown" >Delete
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="deleteinstructor_index.php">Instructor</a></li>
		  <li><a href="deletestudent_index.php">Student</a></li>
          <li><a href="deletecourse_index.php">Course</a></li>
        </ul>
      </li>
	   <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" >Edit
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="edituser_index.php">User</a></li>
          <li><a href="editcourse_index.php">Course</a></li>
        </ul>
      </li>
	    <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" >View
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="viewuser.php">User</a></li>
          <li><a href="viewcourse.php">Course</a></li>
        </ul>
      </li>
	   </ul>
	     <div class="form-group">	
		 
                      <form action="search.php" method="POST" class="navbar-form navbar-left">	

        <input type="text" name="S" class="form-control" placeholder="Search">
		                         <select name="type" >
                         <option value="1">User First Name</option>
                        <option value="2">Course Code</option>
						<option value="3">User User-Name</option>
						<option value="4">Course Name</option>
						
                        </select>  
		<button type="submit" name="search" class="btn btn-primary btn-sm">Search</button>
      </div>
      
   
	</form>
	
	 <ul class="nav navbar-nav navbar-right">
                
                    <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout </a>
                
            </ul>
  </div>
</nav>

  <div class="form">
                      		  
        	<div class="panel panel-default">
        		<div class="panel-heading">
			    		<h3 class="panel-title">Course List</h3>
			 			</div>
						<div class="panel-body">
			   

					 <?php
                   include("database.php");
                    $sorgu=mysql_query("select * from course ");
  
                   echo "<table>"; 
				 							   		   
    echo '<th>Course Code</th>';
	echo '<td>&nbsp</td>';
    echo'<th>Course Name</th>';
	
while($kayit=mysql_fetch_array($sorgu)){

  echo '<tr>';
	echo'<td>'.$kayit["course_code"].'</td>';
	echo '<td>&nbsp</td>';
	echo'<td>'.$kayit["course_name"].'</td>';
      
 echo '</tr>';
}


echo "</table>";
 
   ?>
               
                
                    </div>
                </form>
            </div>
        </div>
    </div>
	</div>

	
</body>
</html>