<?php
include "functions.php";
session_start();
$selectedCourseID=0;
if($_SERVER["REQUEST_METHOD"]=="POST" && isset($_POST["courseID"] ))
{
   $selectedCourseID=$_POST["courseID"]; 


    if($_SESSION["logged_user_role"] != "Student")
    {
        header('Location: mainPage.php');
    }


}


$question=getQuestions($selectedCourseID);
?>

<!DOCTYPE html>
<html>
<head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <script src="js/jquery-1.12.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/exam.css">
        <title>Online Exam System</title>
</head>
<body>
    <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Online Exam System</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="mainPage.php">MainPage</a></li>
                        <li class="active"><a href="courseStudentPage.php">My Courses</a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <?php
                        if(isset($_SESSION["logged_user_username"]) && isset($_SESSION["logged_user_password"]) && isset($_SESSION["logged_user_role"]))
                        {
                           $personalPageLink="#";
                           switch ($_SESSION["logged_user_role"])
                           {
                                case "Instructor":
                                    $personalPageLink="instructorPage.php";
                                    break;
                                case "Student":
                                    $personalPageLink="studentPage.php";
                                    break;
                           }
                           ?>
                           <li>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>
                            Welcome <b> <?php echo $_SESSION["logged_user_username"] ?> <span class="caret"></span></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo $personalPageLink; ?>">Personal</a></li>
                                <li><a href="changeStudentPass.php">Change Password</a></li>
                            </ul>
                           </li>
                           <li>
                            <a href="logoutt.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
                           </li>
                           <?php
                        }
                        ?>
                    </ul>
                </div>
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>    
            </div>
        </nav>
    <div class="row">
        <div class="col-lg-12 text-center">
            <div class="card-view">
                <div class="h3">
                    <?php echo $selectedCourseID; ?>
                </div>
                <?php
                if($question !=null)
                {
                    while($row=mysqli_fetch_assoc($question))
                    {
                        ?>
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="h6">
                                    <?php echo $row["question_text"]; ?>
                                </div>
                               <div class="form-group">
                                <input type="radio" name="ans1" id="ans2" value="<?php echo $row["question_ans1"]; ?>">
                               </div>
                            </div>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>