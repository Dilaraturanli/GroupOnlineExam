<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>



<?php
if($_POST["button"]){
   $username=$_POST["username"];
   $firstname=$_POST["firstname"];
   $lastname=$_POST["lastname"];
   $password=$_POST["password"];
	$userrole=$_POST["userrole"];
	$email=$_POST["email"];
	$course=$_POST["course"];
	//$course=implode($course,",");
	$length=count($course);
	
	   include("database.php"); 
  $sql = mysql_num_rows(mysql_query("select user_username from user where user_username='$username'"));
		if ($sql > 0){
			echo "<center><u><b>ERROR!The user has already been added </b></u><br><a href=adduser_index.php>Turn Back</a></center>";
			}

 else{
	 mysql_query("insert into user (user_id,user_name, user_surname,user_email,user_username,user_password,user_role) VALUES (NULL,'$firstname','$lastname','$email','$username','$password','$userrole')");
 
 $id =mysql_query("select user_id from user where user_username='$username'");
  $satir=mysql_fetch_array($id);

     for($i=0; $i<$length;$i++){
		 mysql_query("insert into hascourse (hasCourse_id,user_id,course_id) VALUES (NULL,'$satir[0]','$course[$i]')");
	 }
	 echo "<center><u><b>The user successfully added</b></u><br><a href=adduser_index.php>Turn Back</a></center>";
 }
	
  
 
 }
?>
