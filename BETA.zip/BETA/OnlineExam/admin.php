<?php
$adminUserName = $adminPassword = "";

if($_SERVER["REQUEST_METHOD"]=="POST" && isset($_POST["adminUserName"]) && isset($_POST["adminPassword"]) && !empty($_POST["adminUserName"]) && !empty($_POST["adminPassword"]))
{
    function test_input($data)
    {
        $data=trim($data);
        $data=stripcslashes($data);
        $data=htmlspecialchars($data);
        return $data;
    }
    $adminUserName=test_input($_POST["adminUserName"]);
    $adminPassword=test_input($_POST["adminPassword"]);
    
    $servername= "localhost:3306";
    $username="root";
    $password="";
    $conn=mysqli_connect($servername, $username, $password, "onlineexam");
    
    
    
    mysqli_set_charset($conn,'utf8');
    
    $sql="SELECT a.admin_username, a.admin_password FROM admininfo as a WHERE a.admin_username='". $adminUserName . "' AND a.admin_password '" . $adminPassword . "'";
    $result =mysqli_query($conn, $sql);
    if(mysqli_num_rows($result)>0)
    {
        ob_start();
        session_start();
        $row==mysqli_fetch_assoc($result);
        $_SESSION["logged_admin_username"]=$row["admin_username"];
        $_SESSION["logged_admin_userpassword"]=$row["admin_password"];
        ob_end_flush();
    }
    else
    {
        header('Location: adminPage.php');
        setcookie("noUser","noUser",time() + (1));
    }
    $conn->close();
    

}
else
{
    header('Location: adminPage.php');
    setcookie("emptyData", "emptydata", time()+(1));
}
?>