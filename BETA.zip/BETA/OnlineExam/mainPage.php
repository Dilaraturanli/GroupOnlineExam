<?php
include "functions.php";
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <script src="js/jquery-1.12.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/exam.css">
        <title>Online Exam System</title>
    </head>
    <body>
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Online Exam System</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                     <li class="active"><a href="mainPage.php">MainPage</a></li>   
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <?php
                        if(isset($_SESSION["logged_user_username"]) && isset($_SESSION["logged_user_password"]) && isset($_SESSION["logged_user_role"]))
                        {
                          $personalPageLink = "#";
                          $personalChangePass = "#";
                          switch ($_SESSION["logged_user_role"])
                          {
                            case "Instructor":
                                $personalPageLink = "instructorPage.php";
                                $personalChangePass = "changeInstructorPass";
                                break;
                            case "Student":
                                $personalPageLink = "studentPage.php";
                                $personalChangePass = "changeStudentPass";
                                break;
                          }
                          ?>
                          <li>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>
                                Welcome <b> <?php echo $_SESSION["logged_user_username"] ?> <span class="caret"></span></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo $personalPageLink; ?>">Personal Page</a></li>
                                <li><a href="<?php echo $personalChangePass; ?>">Change Password</a></li>
                            </ul>
                          </li>
                          <li>
                            <a href="logoutt.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
                          </li>
                          <?php
                        }
                        else
                        {
                            ?>
                            <li>
                                <a href="loginPage.php"><span class="glyphicon glyphicon-log-in"></span> Login</a>
                            </li>
                            <?php
                        }
                        ?>
                    </ul>
                </div>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            </div>
        </nav>
        <div class="container">
            <div class="container-fluid">
                <?php if(isset($_COOKIE['forbiddenPage'])) { ?>
                <div class="alert alert-danger fade in">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Forbidden for your account !</strong>
                </div>
                    <?php
                }
                ?>
                <div class="page-header">
                    <img class="img-responsive" src="C:\Users\SONY\Desktop\isik3.png">
                </div>
            </div>
        </div>
    </body>
</html>