-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 02 Oca 2017, 04:44:52
-- Sunucu sürümü: 5.7.9
-- PHP Sürümü: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `examonline`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admininfo`
--

DROP TABLE IF EXISTS `admininfo`;
CREATE TABLE IF NOT EXISTS `admininfo` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(50) NOT NULL,
  `admin_password` varchar(50) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `admininfo`
--

INSERT INTO `admininfo` (`admin_id`, `admin_username`, `admin_password`) VALUES
(1, 'cilgincoderlar', '1234');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `answer`
--

DROP TABLE IF EXISTS `answer`;
CREATE TABLE IF NOT EXISTS `answer` (
  `answer_id` int(11) NOT NULL AUTO_INCREMENT,
  `answer_key` varchar(250) NOT NULL,
  PRIMARY KEY (`answer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `course`
--

DROP TABLE IF EXISTS `course`;
CREATE TABLE IF NOT EXISTS `course` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(50) NOT NULL,
  `course_code` varchar(8) NOT NULL,
  `course_credit` int(1) NOT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `course`
--

INSERT INTO `course` (`course_id`, `course_name`, `course_code`, `course_credit`) VALUES
(2, 'Software Engineering', 'se301', 3),
(3, 'Computer Network', 'cse334', 3);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `exam`
--

DROP TABLE IF EXISTS `exam`;
CREATE TABLE IF NOT EXISTS `exam` (
  `exam_id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_name` varchar(50) NOT NULL,
  PRIMARY KEY (`exam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `exam`
--

INSERT INTO `exam` (`exam_id`, `exam_name`) VALUES
(1, 'midterm'),
(2, 'final');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hasanswer`
--

DROP TABLE IF EXISTS `hasanswer`;
CREATE TABLE IF NOT EXISTS `hasanswer` (
  `hasAnswer_id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `answer_id` int(11) NOT NULL,
  PRIMARY KEY (`hasAnswer_id`),
  KEY `question_id` (`question_id`),
  KEY `answer_id` (`answer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hascourse`
--

DROP TABLE IF EXISTS `hascourse`;
CREATE TABLE IF NOT EXISTS `hascourse` (
  `hasCourse_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  PRIMARY KEY (`hasCourse_id`),
  KEY `user_id` (`user_id`),
  KEY `course_id` (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `hascourse`
--

INSERT INTO `hascourse` (`hasCourse_id`, `user_id`, `course_id`) VALUES
(14, 9, 2),
(15, 9, 3),
(16, 10, 2),
(17, 10, 3);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hasexam`
--

DROP TABLE IF EXISTS `hasexam`;
CREATE TABLE IF NOT EXISTS `hasexam` (
  `hasExam_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  PRIMARY KEY (`hasExam_id`),
  KEY `course_id` (`course_id`),
  KEY `exam_id` (`exam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `hasexam`
--

INSERT INTO `hasexam` (`hasExam_id`, `course_id`, `exam_id`) VALUES
(18, 3, 2),
(19, 3, 2);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hasquestion`
--

DROP TABLE IF EXISTS `hasquestion`;
CREATE TABLE IF NOT EXISTS `hasquestion` (
  `hasQuestion_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  PRIMARY KEY (`hasQuestion_id`),
  KEY `question_id` (`question_id`),
  KEY `course_id` (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `hasquestion`
--

INSERT INTO `hasquestion` (`hasQuestion_id`, `course_id`, `question_id`) VALUES
(4, 2, 5),
(5, 3, 8),
(6, 3, 45),
(7, 3, 46);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `question`
--

DROP TABLE IF EXISTS `question`;
CREATE TABLE IF NOT EXISTS `question` (
  `question_id` int(11) NOT NULL AUTO_INCREMENT,
  `question_num` int(11) NOT NULL,
  `question_text` varchar(500) NOT NULL,
  `question_ans1` varchar(250) NOT NULL,
  `question_ans2` varchar(250) NOT NULL,
  `question_ans3` varchar(250) NOT NULL,
  `question_ans4` varchar(250) NOT NULL,
  PRIMARY KEY (`question_id`),
  KEY `question_num` (`question_num`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `question`
--

INSERT INTO `question` (`question_id`, `question_num`, `question_text`, `question_ans1`, `question_ans2`, `question_ans3`, `question_ans4`) VALUES
(21, 9, 'sdfsdf', 'dsdssdf', 'dssdfsdf', 'dfsdfsdf', 'dfdsfdf'),
(22, 5, 'efe', 'efef', 'efef', 'efef', 'efe'),
(23, 5, 'efe', 'efef', 'efef', 'efef', 'efe'),
(24, 8, 'hyhy', 'rhgh', 'fgngn', 'nhnn', 'hnghn'),
(25, 8, 'hyhy', 'rhgh', 'fgngn', 'nhnn', 'hnghn'),
(26, 45, 'fdfdf', 'sdfdf', 'sdfdf', 'sdfdf', 'sdfdf'),
(27, 46, 'hghgh', 'ddfsds', 'dsdsd', 'dsds', 'dsdsd');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(25) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `role`
--

INSERT INTO `role` (`role_id`, `role_name`) VALUES
(1, 'Instructor'),
(2, 'Student');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `user_surname` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_username` varchar(50) NOT NULL,
  `user_password` int(11) NOT NULL,
  `user_role` int(11) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_username` (`user_username`),
  KEY `user_role` (`user_role`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_surname`, `user_email`, `user_username`, `user_password`, `user_role`) VALUES
(5, 'tuba', 'metin', 'aslitubametin@hotmail.com', 'amele', 1234, 2),
(6, 'kÄ±z', 'asli', 'asli@gmail.com', 'deli', 1234, 2),
(7, 'tuba', 'cetin', 'fts.atm@gmail.com', 'tubametin', 1234, 2),
(9, 'metin', 'asli', 'aslitubametin@hotmail.com', 'aslituba', 1234, 1),
(10, 'asliasli', 'metin', 'didar@gmail.com', 'metintuba', 1234, 2);

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `answer`
--
ALTER TABLE `answer`
  ADD CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`answer_id`) REFERENCES `hasanswer` (`answer_id`);

--
-- Tablo kısıtlamaları `hasanswer`
--
ALTER TABLE `hasanswer`
  ADD CONSTRAINT `hasanswer_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_num`);

--
-- Tablo kısıtlamaları `hascourse`
--
ALTER TABLE `hascourse`
  ADD CONSTRAINT `hascourse_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `hascourse_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`);

--
-- Tablo kısıtlamaları `hasexam`
--
ALTER TABLE `hasexam`
  ADD CONSTRAINT `hasexam_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`),
  ADD CONSTRAINT `hasexam_ibfk_2` FOREIGN KEY (`exam_id`) REFERENCES `exam` (`exam_id`);

--
-- Tablo kısıtlamaları `hasquestion`
--
ALTER TABLE `hasquestion`
  ADD CONSTRAINT `hasquestion_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`),
  ADD CONSTRAINT `hasquestion_ibfk_3` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_num`);

--
-- Tablo kısıtlamaları `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`user_role`) REFERENCES `role` (`role_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
