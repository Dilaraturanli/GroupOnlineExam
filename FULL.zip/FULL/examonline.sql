-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 13 Oca 2017, 03:38:38
-- Sunucu sürümü: 5.7.9
-- PHP Sürümü: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `examonline`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admininfo`
--

DROP TABLE IF EXISTS `admininfo`;
CREATE TABLE IF NOT EXISTS `admininfo` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(50) NOT NULL,
  `admin_password` varchar(50) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `admininfo`
--

INSERT INTO `admininfo` (`admin_id`, `admin_username`, `admin_password`) VALUES
(2, 'didarturanli', '1234'),
(3, 'dilaraturanli', '1234');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `answer`
--

DROP TABLE IF EXISTS `answer`;
CREATE TABLE IF NOT EXISTS `answer` (
  `answer_id` int(11) NOT NULL AUTO_INCREMENT,
  `answer_key` varchar(250) NOT NULL,
  PRIMARY KEY (`answer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `answer`
--

INSERT INTO `answer` (`answer_id`, `answer_key`) VALUES
(1, 'a'),
(2, 'b'),
(3, 'c'),
(4, 'd');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `course`
--

DROP TABLE IF EXISTS `course`;
CREATE TABLE IF NOT EXISTS `course` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(50) NOT NULL,
  `course_code` varchar(8) NOT NULL,
  `course_credit` int(1) NOT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `course`
--

INSERT INTO `course` (`course_id`, `course_name`, `course_code`, `course_credit`) VALUES
(2, 'Software Engineering', 'SE301', 4),
(3, 'Computer Network', 'CSE334', 3),
(5, 'Analysis of Algorithms', 'CSE312', 3),
(6, 'Internet and Web Programming', 'SE311', 3),
(7, 'Communication Network Applications', 'CSE436', 3);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `exam`
--

DROP TABLE IF EXISTS `exam`;
CREATE TABLE IF NOT EXISTS `exam` (
  `exam_id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_name` varchar(50) NOT NULL,
  PRIMARY KEY (`exam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `exam`
--

INSERT INTO `exam` (`exam_id`, `exam_name`) VALUES
(1, 'midterm'),
(2, 'final');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `examinfo`
--

DROP TABLE IF EXISTS `examinfo`;
CREATE TABLE IF NOT EXISTS `examinfo` (
  `examinfo_id` int(11) NOT NULL AUTO_INCREMENT,
  `examinfo_num` int(11) NOT NULL,
  `starting_time` int(11) NOT NULL,
  `finishing_time` int(11) NOT NULL,
  `examinfo_date` date NOT NULL,
  PRIMARY KEY (`examinfo_id`),
  KEY `examinfo_num` (`examinfo_num`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `examinfo`
--

INSERT INTO `examinfo` (`examinfo_id`, `examinfo_num`, `starting_time`, `finishing_time`, `examinfo_date`) VALUES
(1, 5, 11, 3, '2017-01-03');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hasanswer`
--

DROP TABLE IF EXISTS `hasanswer`;
CREATE TABLE IF NOT EXISTS `hasanswer` (
  `hasAnswer_id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `answer_id` int(11) NOT NULL,
  PRIMARY KEY (`hasAnswer_id`),
  KEY `question_id` (`question_id`),
  KEY `answer_id` (`answer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hascourse`
--

DROP TABLE IF EXISTS `hascourse`;
CREATE TABLE IF NOT EXISTS `hascourse` (
  `hasCourse_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  PRIMARY KEY (`hasCourse_id`),
  KEY `user_id` (`user_id`),
  KEY `course_id` (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `hascourse`
--

INSERT INTO `hascourse` (`hasCourse_id`, `user_id`, `course_id`) VALUES
(22, 12, 6),
(23, 12, 5),
(24, 12, 3),
(25, 12, 2),
(26, 14, 2),
(27, 14, 3),
(28, 14, 5),
(29, 15, 2),
(30, 16, 6),
(32, 16, 2),
(33, 16, 3);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hasexam`
--

DROP TABLE IF EXISTS `hasexam`;
CREATE TABLE IF NOT EXISTS `hasexam` (
  `hasExam_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  PRIMARY KEY (`hasExam_id`),
  KEY `course_id` (`course_id`),
  KEY `exam_id` (`exam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `hasexam`
--

INSERT INTO `hasexam` (`hasExam_id`, `course_id`, `exam_id`) VALUES
(29, 2, 1),
(30, 2, 2),
(31, 3, 2),
(32, 2, 2);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hasquestion`
--

DROP TABLE IF EXISTS `hasquestion`;
CREATE TABLE IF NOT EXISTS `hasquestion` (
  `hasQuestion_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  PRIMARY KEY (`hasQuestion_id`),
  KEY `question_id` (`question_id`),
  KEY `course_id` (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `hasquestion`
--

INSERT INTO `hasquestion` (`hasQuestion_id`, `course_id`, `question_id`) VALUES
(27, 2, 989),
(28, 2, 100),
(29, 2, 87);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hasstartexam`
--

DROP TABLE IF EXISTS `hasstartexam`;
CREATE TABLE IF NOT EXISTS `hasstartexam` (
  `hasStartExam_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `examinfo_id` int(11) NOT NULL,
  PRIMARY KEY (`hasStartExam_id`),
  KEY `course_id` (`course_id`),
  KEY `exam_id` (`exam_id`),
  KEY `question_id` (`question_id`),
  KEY `examinfo_id` (`examinfo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `question`
--

DROP TABLE IF EXISTS `question`;
CREATE TABLE IF NOT EXISTS `question` (
  `question_id` int(11) NOT NULL AUTO_INCREMENT,
  `question_num` int(11) NOT NULL,
  `question_text` varchar(500) NOT NULL,
  `question_ans1` varchar(250) NOT NULL,
  `question_ans2` varchar(250) NOT NULL,
  `question_ans3` varchar(250) NOT NULL,
  `question_ans4` varchar(250) NOT NULL,
  PRIMARY KEY (`question_id`),
  KEY `question_num` (`question_num`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `question`
--

INSERT INTO `question` (`question_id`, `question_num`, `question_text`, `question_ans1`, `question_ans2`, `question_ans3`, `question_ans4`) VALUES
(47, 4, 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'asdasd'),
(48, 4, 'rferf', 'erferf', 'erfe', 'erfrf', 'erferf'),
(50, 34, 'dfsdfsdfdsfefef', 'vbvbvb', 'bggbgbg', 'bgbfgbfg', 'erwerwer'),
(51, 989, 'merhabalarrcaaalardan bir demetiii', 'dfdf', 'sdfsdfsd', 'gererg', 'ergrg'),
(52, 100, 'gdfgdf', 'dfgdfg', 'dfgfg', 'dfgfdg', 'dfgfg'),
(53, 87, 'gdfg', 'dfgf', 'dfgf', 'dfgfdg', 'dfgf');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(25) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `role`
--

INSERT INTO `role` (`role_id`, `role_name`) VALUES
(1, 'Instructor'),
(2, 'Student');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `user_surname` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_username` varchar(50) NOT NULL,
  `user_password` int(11) NOT NULL,
  `user_role` int(11) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_username` (`user_username`),
  KEY `user_role` (`user_role`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_surname`, `user_email`, `user_username`, `user_password`, `user_role`) VALUES
(12, 'aysenur', 'bayram', 'aysenurbayram93@gmail.com', 'aysenur', 1234, 1),
(13, 'aysenur', 'bayram', 'aysenurbayram93@gmail.com', 'aysenurbayram', 1234, 1),
(14, 'asli', 'tuba', 'aslitubametin91@gmail.com', 'aslituba', 1234, 1),
(15, 'aysenur', 'bayram', 'ays@hotmail.com', 'aysenurr', 1234, 1),
(16, 'ayse', 'bayram', 'ay@hotmail.com', 'ayse', 1234, 2);

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `hasanswer`
--
ALTER TABLE `hasanswer`
  ADD CONSTRAINT `hasanswer_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_num`),
  ADD CONSTRAINT `hasanswer_ibfk_2` FOREIGN KEY (`answer_id`) REFERENCES `answer` (`answer_id`);

--
-- Tablo kısıtlamaları `hascourse`
--
ALTER TABLE `hascourse`
  ADD CONSTRAINT `hascourse_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `hascourse_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`);

--
-- Tablo kısıtlamaları `hasquestion`
--
ALTER TABLE `hasquestion`
  ADD CONSTRAINT `hasquestion_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`),
  ADD CONSTRAINT `hasquestion_ibfk_3` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_num`);

--
-- Tablo kısıtlamaları `hasstartexam`
--
ALTER TABLE `hasstartexam`
  ADD CONSTRAINT `hasstartexam_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`),
  ADD CONSTRAINT `hasstartexam_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_num`),
  ADD CONSTRAINT `hasstartexam_ibfk_3` FOREIGN KEY (`exam_id`) REFERENCES `exam` (`exam_id`),
  ADD CONSTRAINT `hasstartexam_ibfk_4` FOREIGN KEY (`examinfo_id`) REFERENCES `examinfo` (`examinfo_num`);

--
-- Tablo kısıtlamaları `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`user_role`) REFERENCES `role` (`role_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
