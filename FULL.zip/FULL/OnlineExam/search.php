<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
	
}

?>



<?php

 include("database.php"); 
   $Search=$_POST["S"];
  
$type=$_POST["type"]; 

if($type==1){

$sql= mysql_query("SELECT * FROM user WHERE user_name like '%".$Search."%'");

$toplamsonuc = mysql_num_rows($sql);

}
elseif($type==2){

$sql= mysql_query("SELECT * FROM course WHERE course_code like'%".$Search."%'");
$toplamsonuc = mysql_num_rows($sql);
}
else if($type==3){

$sql= mysql_query("SELECT * FROM user WHERE user_username like'%".$Search."%'");
$toplamsonuc = mysql_num_rows($sql);
}
else if($type==4){

$sql= mysql_query("SELECT * FROM course WHERE course_name like'%".$Search."%'");
$toplamsonuc = mysql_num_rows($sql);
}




if(($Search!=NULL)&&($toplamsonuc > 0)){
echo "Total result of found is:" ;
echo "$toplamsonuc <br><br>";
}
else{
echo "Record is not found! OR Incorrect type selection ";
}
while ($row = mysql_fetch_array($sql)){
extract($row);
if($type==1){
  echo "<table>"; 
echo '<th>User ID</th>';
	echo '<td>&nbsp</td>';  
    echo '<th>User Name</th>';
	echo '<td>&nbsp</td>';
    echo'<th>First Name</th>';
	echo '<td>&nbsp</td>';
    echo'<th>Last Name</th>';
    echo '<td>&nbsp</td>';
    echo'<th>E-mail</th>';	
echo '<td>&nbsp</td>';
    echo'<th>User Role</th>';	
  echo '<tr>';
	echo'<td>'.$row["user_id"].'</td>';
	echo '<td>&nbsp</td>';
	echo'<td>'.$row["user_username"].'</td>';
	echo '<td>&nbsp</td>';
	echo'<td>'.$row["user_name"].'</td>';
	echo '<td>&nbsp</td>';
	echo'<td>'.$row["user_surname"].'</td>';
	echo '<td>&nbsp</td>';
	echo'<td>'.$row["user_email"].'</td>';
	echo '<td>&nbsp</td>';
	if($row["user_role"]==1){
	echo'<td>Instructor</td>';
	}
	if($row["user_role"]==2){
	echo'<td>Student</td>';
	}	
 echo '</tr>';
	  echo "</table>"; 



}

else if ($type==2){
	
       echo "<table>"; 							   		   
    echo '<th>Course Code</th>';
	echo '<td>&nbsp</td>';
    echo'<th>Course Name</th>';
	echo '<td>&nbsp</td>';
    echo'<th>Course Credit</th>';	
  echo '<tr>';
	echo'<td>'.$row["course_code"].'</td>';
	echo '<td>&nbsp</td>';
	echo'<td>'.$row["course_name"].'</td>';
	echo '<td>&nbsp</td>';
	echo'<td>'.$row["course_credit"].'</td>';
      
 echo '</tr>';
	  echo "</table>"; 
}
else if($type==3){
  echo "<table>"; 
echo '<th>User ID</th>';
	echo '<td>&nbsp</td>';  
    echo '<th>User Name</th>';
	echo '<td>&nbsp</td>';
    echo'<th>First Name</th>';
	echo '<td>&nbsp</td>';
    echo'<th>Last Name</th>';
    echo '<td>&nbsp</td>';
    echo'<th>E-mail</th>';	
echo '<td>&nbsp</td>';
    echo'<th>User Role</th>';	
  echo '<tr>';
	echo'<td>'.$row["user_id"].'</td>';
	echo '<td>&nbsp</td>';
	echo'<td>'.$row["user_username"].'</td>';
	echo '<td>&nbsp</td>';
	echo'<td>'.$row["user_name"].'</td>';
	echo '<td>&nbsp</td>';
	echo'<td>'.$row["user_surname"].'</td>';
	echo '<td>&nbsp</td>';
	echo'<td>'.$row["user_email"].'</td>';
	echo '<td>&nbsp</td>';
	if($row["user_role"]==1){
	echo'<td>Instructor</td>';
	}
	if($row["user_role"]==2){
	echo'<td>Student</td>';
	}	
 echo '</tr>';
	  echo "</table>"; 



}
else if ($type==4){
	
       echo "<table>"; 							   		   
    echo '<th>Course Code</th>';
	echo '<td>&nbsp</td>';
    echo'<th>Course Name</th>';
	echo '<td>&nbsp</td>';
    echo'<th>Course Credit</th>';	
  echo '<tr>';
	echo'<td>'.$row["course_code"].'</td>';
	echo '<td>&nbsp</td>';
	echo'<td>'.$row["course_name"].'</td>';
	echo '<td>&nbsp</td>';
	echo'<td>'.$row["course_credit"].'</td>';
      
 echo '</tr>';
	  echo "</table>"; 
}
}

?>

