<?php
include "functions.php";
session_start();
if(isset($_SESSION["logged_user_role"]))
{
    switch($_SESSION["logged_user_role"])
    {
        case "Student":
            header('Location: mainPage.php');
            setcookie("forbiddenPage" , "forbiddenPage" , time() + (2));
            break;
    }
}
elseif(!isset($_SESSION["logged_user_role"]))
{
    header('Location: loginPage.php');
    setcookie("loginFirst" , "loginFirst" , time() + (2));
}
echo $saat=date("H:i"); 
$myCourse=getStudentCourse($_SESSION["logged_user_username"]);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <script src="js/jquery-1.12.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/exam.css">
        <title>Online Exam System</title>
    </head>
    <body>
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Online Exam System</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="mainPage.php">MainPage</a></li>
                        <li><a href="courseInstructorPage.php">Courses</a></li>
						<li><a href="createExamPage.php">Create Exam</a></li>	
						
                            
							
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <?php
                        if(isset($_SESSION["logged_user_username"]) && isset($_SESSION["logged_user_password"]) && isset($_SESSION["logged_user_role"]))
                        {
                           $personalPageLink="#";
                           switch ($_SESSION["logged_user_role"])
                           {
                                case "Instructor":
                                    $personalPageLink="instructorPage.php";
                                    break;
                                case "Student":
                                    $personalPageLink="studentPage.php";
                                    break;
                           }
                           ?>
                           <li>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>
                            Welcome <b> <?php echo $_SESSION["logged_user_username"] ?> <span class="caret"></span></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo $personalPageLink; ?>">Personal</a></li>
                                <li><a href="changeInstructorPass.php">Change Password</a></li>
                            </ul>
                           </li>
                           <li>
                            <a href="logoutt.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
                           </li>
                           <?php
                        }
                        ?>
                    </ul>
                </div>
                   
            </div>
        </nav>
        <div class="container">
            <div class="container-fluid">
				<?php
                if(isset($_COOKIE['successEdit']))
                {
                    ?>
                    <div class="alert alert-success fade in">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong> Edit question is done successfully.</strong>
                    </div>
                    <?php
                }
				if(isset($_COOKIE['successDelete']))
                {
                    ?>
                    <div class="alert alert-success fade in">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong> Delete question is done successfully.</strong>
                    </div>
                    <?php
                }
				
                ?>
				<?php
                if(isset($_COOKIE['successAdd']))
                {
                    ?>
                    <div class="alert alert-success fade in">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong> Add question is done successfully.</strong>
                    </div>
                    <?php
                }
                ?>
                <div class="page-header">
                    <h2>Course List</h2>
                </div>
                <?php
                if($myCourse !=null)
                {
                    while($row=mysqli_fetch_assoc($myCourse))
                    {
                        ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card-view">
                                    <div class="col-lg-4">
                                        <div class="h3">
                                            <?php echo $row["course_name"];?>
											 
                                        </div>
										
                                    </div>
									
									
                                    <div class="col-lg-4">
                                        <div class="h4">
										Course Code
										
										</div>
                                        <div class="col-lg-offset-0">
										
                                            <?php echo $row["course_code"]; ?>
											
                                        </div>
										<form method="post" action="seeSelectedQuestion.php" role="form">
										<input type="hidden" name="courseID" class="form-control" value="<?php echo $row["course_id"];?>">
										<div class="form-group">
											<input class="btn btn-danger form-group" type="submit" value="See Questions">
										</div>
									</form>
										
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="h4">
										Course Credit
										</div>
                                        <div class="col-lg-offset-0">
										
                                            <?php echo $row["course_credit"]; ?>
											
                                        </div>
										<form method="post" action="addQuestionPage.php" role="form">
											<input type="hidden" name="courseID2" class="form-control" value="<?php echo $row["course_id"];?>">
											<input type="hidden" name="courseID3" class="form-control" value="<?php echo $row["course_name"];?>">											<div class="form-group">
												<input class="btn btn-success form-group" type="submit" value="Add Question">
											</div>
										</form>
										
                                    </div>
									
									
									
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                }
                else
                {
                    ?>
                    <div class="h4">There is no course belongs to you:(</div>
                    <?php
                }
                ?>
            </div>
        </div>
    </body>
</html>    