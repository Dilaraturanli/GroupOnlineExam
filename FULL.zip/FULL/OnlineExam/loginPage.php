<?php
include "functions.php";
session_start();
if(isset($_SESSION["logged_user_role"]))
{
    switch($_SESSION["logged_user_role"])
    {
        case "Instructor":
            header('Location: instructorPage.php');
            break;
        case "Student":
            header('Location: studentPage.php');
            break;
        
    }
}

$roles = getRoles();
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/exam.css">
    <title>Online Exam System</title>
</head>
<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#"> Online Exam System</a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li><a href="mainPage.php"> MainPage </a></li>
				
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="active">
                    <a href="forgetPassword.php"><span class="glyphicon glyphicon-edit"></span> Forget Password? </a>
                </li>
                
            </ul>
        </div>
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
        </button>
        </div>
        
    </nav>
 <div class="container">
    <div class="container-fluid">
        <?php if (isset($_COOKIE['loginFirst'])) { ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>You should login first.</strong>
            </div>
        <?php
        }
        ?>
        <?php
        if(isset($_COOKIE['noUser']))
        {
            ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>User name or password is wrong. Also control your account type.</strong>
            </div>
            <?php
        }
        ?>
        <?php
        if(isset($_COOKIE['emptyData']))
        {
            ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Please fill necessary fields.</strong>
            </div>
            <?php
        }
        ?>
        <?php if (isset($_COOKIE['loggedOut'])) { ?>
            <div class="alert alert-success fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>You have been logged out safely.</strong>
            </div>
        <?php } ?>
        
        
        
<div class="row">
    <div class="col-lg-12 text-center">
        <div class="card-view">
            <form action="loginn.php" method="post" role="form">
                <div class="form-group">
                    <label class="pull-left" for="userName">Enter your User Name:</label>
                    <input type="text" required name="userName" id="userName" class="form-control">
                    
                    
                </div>
                <div class="form-group">
                    <label class="pull-left" for="userPassword">Enter your Password:</label>
                    <input type="password" required name= "userPassword" id="userPassword" class="form-control">
                </div>
                <div class="form-group">
                    <label for="roleList">Select your account type:</label>
                    <select class="form-control"name="roleList" id="roleList">
                        <?php
                        if ($roles !=null)
                        {
                            while($row =mysqli_fetch_assoc($roles))
                            {
                                ?>
                                <option
                                        value="<?php echo $row["role_id"]; ?>"><?php echo $row["role_name"]; ?></option>
                                    
                                <?php
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group pull-right">
                    <input type="submit" name="tryLogin" class="btn btn-primary" value="Login">
                </div>
            </form>
            
        </div>
        
    </div>
    </div>
 </div>    
</div>
</body>
</html>
    

