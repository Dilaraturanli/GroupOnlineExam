<?php
include "functions.php";
session_start();
if(isset($_SESSION["logged_user_username"]))
{
   if(!isset($_POST["questionNum"]))
   {
      header('Location: courseInstructorPage.php');
   }
   if($_SESSION["logged_user_role"]!="Instructor")
   {
      header('Location: mainPage.php');
   }
}
else
{
   header('Location: loginPage.php');   
}
$selectedQuestion=0;
if(isset($_POST["questionNum"]))
{
   $selectedQuestion=$_POST["questionNum"];
}
$course=getInstructorCourse($_SESSION["logged_user_username"]);
$question=getQuestionsQuestion($_POST["questionNum"]);
$exam=getExamName();
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta charset="UTF-8">
            <script src="js/jquery-1.12.3.min.js"></script>
            <script src="js/bootstrap.min.js"></script>
            <link rel="stylesheet" href="css/bootstrap.css">
            <link rel="stylesheet" href="css/exam.css">
            <title>Online Exam System</title>
</head>
<body>
    <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Online Exam System</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="mainPage.php">MainPage</a></li>
                        <li><a href="courseInstructorPage.php">Courses</a></li>
                            
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <?php
                        if(isset($_SESSION["logged_user_username"]) && isset($_SESSION["logged_user_password"]) && isset($_SESSION["logged_user_role"]))
                        {
                           $personalPageLink="#";
                           switch ($_SESSION["logged_user_role"])
                           {
                                case "Instructor":
                                    $personalPageLink="instructorPage.php";
                                    break;
                                case "Student":
                                    $personalPageLink="studentPage.php";
                                    break;
                           }
                           ?>
                           <li>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>
                            Welcome <b> <?php echo $_SESSION["logged_user_username"] ?> <span class="caret"></span></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo $personalPageLink; ?>">Personal</a></li>
                                <li><a href="changeInstructorPass.php">Change Password</a></li>
                            </ul>
                           </li>
                           <li>
                            <a href="logoutt.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
                           </li>
                           <?php
                        }
                        ?>
                    </ul>
                </div>
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>   
            </div>
        </nav>
    <div class="container">
        <div class="container-fluid">
            <div class="row">
                <form action="functions.php" method="post" role="form">
                    <div class="col-lg-4">
                        <div class="page-header">
                            <h2>Edit Questions</h2>
                        </div>
                        <?php
                        if($question!=null)
                        {
                            while($row=mysqli_fetch_assoc($question))
                            {
                                ?>
                                <form action="functions.php" method="post" role="form">
                                    <div class="col-lg-4">
                                        <div class="card-view">
                                            <div class="form-group">
                                                <label for="questionNum">Question Number: </label>
                                                <input readonly="readonly" class="form-control" name="questionNum" value="<?php echo $selectedQuestion;?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="questionText">Question Text: </label>
                                                <input required type="text" class="form-control" name="questionText" value="<?php echo $row["question_text"];?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="questionAns1">Question Ans1: </label>
                                                <input required type="text" class="form-control" name="questionAns1" value="<?php echo $row["question_ans1"];?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="questionAns2">Question Ans2: </label>
                                                <input required type="text" class="form-control" name="questionAns2" value="<?php echo $row["question_ans2"];?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="questionAns3">Question Ans3: </label>
                                                <input required type="text" class="form-control" name="questionAns3" value="<?php echo $row["question_ans3"];?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="questionAns4">Question Ans4: </label>
                                                <input required type="text" class="form-control" name="questionAns4" value="<?php echo $row["question_ans4"];?>">
                                            </div>
                                            <div class="form-group pull-right">
                                                
                                                <input type="submit" name="editQuestion" class="btn btn-primary" value="Edit Question">
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <?php
                            }
                        }
                        ?>
                    </div>
                </form>
            </div>
        </div>
        
    </div>
</body>
</html>