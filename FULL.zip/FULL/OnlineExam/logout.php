<?php
session_start();
ob_start();
session_destroy();
echo "<center>You logged out</center>";
header("Refresh: 2; url=login_index.php");
ob_end_flush();
?>