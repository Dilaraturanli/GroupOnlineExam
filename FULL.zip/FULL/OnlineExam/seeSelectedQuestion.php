<?php
include "functions.php";
error_reporting(1);
session_start();
if(isset($_SESSION["logged_user_username"]))
{
   if(!isset($_POST["courseID"]))
   {
      header('Location: courseInstructorPage.php');
   }
   if($_SESSION["logged_user_role"]!="Instructor")
   {
      header('Location: mainPage.php');
   }
}
else
{
   header('Location: loginPage.php');   
}
$selectedCourse=0;
if(isset($_POST["courseID"]))
{
   $selectedCourse=$_POST["courseID"];
}

$question=getQuestions($_POST["courseID"]);

?>
<!DOCTYPE html>
    <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta charset="UTF-8">
            <script src="js/jquery-1.12.3.min.js"></script>
            <script src="js/bootstrap.min.js"></script>
            <link rel="stylesheet" href="css/bootstrap.css">
            <link rel="stylesheet" href="css/exam.css">
            <title>Online Exam System</title>
        </head>
        <body>
            <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Online Exam System</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="mainPage.php">MainPage</a></li>
                        <li><a href="courseInstructorPage.php">Courses</a></li>
                            
							
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <?php
                        if(isset($_SESSION["logged_user_username"]) && isset($_SESSION["logged_user_password"]) && isset($_SESSION["logged_user_role"]))
                        {
                           $personalPageLink="#";
                           switch ($_SESSION["logged_user_role"])
                           {
                                case "Instructor":
                                    $personalPageLink="instructorPage.php";
                                    break;
                                case "Student":
                                    $personalPageLink="studentPage.php";
                                    break;
                           }
                           ?>
                           <li>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>
                            Welcome <b> <?php echo $_SESSION["logged_user_username"] ?> <span class="caret"></span></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo $personalPageLink; ?>">Personal</a></li>
                                <li><a href="changeInstructorPass.php">Change Password</a></li>
                            </ul>
                           </li>
                           <li>
                            <a href="logoutt.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
                           </li>
                           <?php
                        }
                        ?>
                    </ul>
                </div>
                   
            </div>
        </nav>
        <div class="container">
            <div class="container-fluid">
                <?php
                if(isset($_COOKIE['noQuestion']))
                {
                    ?>
                    <div class="alert alert-success fade in">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong> There is no Question.</strong>
                    </div>
                    <?php
                }
                ?>
                <div class="page-header">
                    <h2>Questions</h2>
                </div>
                <?php
                if($question!=null)
                {
                    while($row=mysqli_fetch_assoc($question))
                    {
                        ?>
                        
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card-view">
                                    <div class="col-lg-4">
                                        <div class="h4">
                                            <b>Question Text</b>
                                        </div>
                                        <div class="h5">
                                            <?php echo $row["question_text"]; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="h4">
                                            <b>Question Answer1</b>
                                        </div>
                                        <div class="h5">
                                            <?php echo $row["question_ans1"];?>
                                        </div>
                                        <div class="h4">
                                            <b>Question Answer2</b>
                                        </div>
                                        <div class="h5">
                                            <?php echo $row["question_ans2"];?>
                                        </div>
                                        <form method="post" action="editQuestionPage.php" role="form">
											<input type="hidden" name="questionNum" class="form-control" value="<?php echo $row["question_num"];?>">
											<div class="form-group">
												<input class="btn btn-danger form-group" type="submit" value="Edit Questions">
											</div>
										</form>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="h4">
                                            <b>Question Answer3</b>
                                        </div>
                                        <div class="h5">
                                            <?php echo $row["question_ans3"];?>
                                        </div>
                                        <div class="h4">
                                            <b>Question Answer4</b>
                                        </div>
                                        <div class="h5">
                                            <?php echo $row["question_ans4"];?>
                                        </div>
                                        <form method="post" action="functions.php" role="form">
											<input type="hidden" name="questionNum2" class="form-control" value="<?php echo $row["question_num"];?>">
											<div class="form-group">
												<input class="btn btn-danger form-group" name="deleteQuestion" type="submit" value="Delete Questions">
											</div>
									</form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                }
                else
                {
                    ?>
                    <div class="h4"> There is no question for this course.</div>
                <?php
                }
                ?>
            </div>
        </div>
        </body>
    </html>