<?php
include "functions.php";

session_start();
if(isset($_SESSION["logged_user_username"]))
{
   if(!isset($_POST["courseID2"]))
   {
      header('Location: courseInstructorPage.php');
   }
   if($_SESSION["logged_user_role"]!="Instructor")
   {
      header('Location: mainPage.php');
   }
}
else
{
   header('Location: loginPage.php');   
}
$selectedCourse=0;
$selectedCourseName="";
if(isset($_POST["courseID2"]))
{
   $selectedCourse=$_POST["courseID2"];
}
if(isset($_POST["courseID3"]))
{
	$selectedCourseName=$_POST["courseID3"];
}


$exam=getExamName();
?>
<!DOCTYPE html>
<html>
    <head>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta charset="UTF-8">
            <script src="js/jquery-1.12.3.min.js"></script>
            <script src="js/bootstrap.min.js"></script>
            <link rel="stylesheet" href="css/bootstrap.css">
            <link rel="stylesheet" href="css/exam.css">
            <title>Online Exam System</title>
    </head>
    <body>
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Online Exam System</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="mainPage.php">MainPage</a></li>
                        <li><a href="courseInstructorPage.php">Courses</a></li>
                            
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <?php
                        if(isset($_SESSION["logged_user_username"]) && isset($_SESSION["logged_user_password"]) && isset($_SESSION["logged_user_role"]))
                        {
                           $personalPageLink="#";
                           switch ($_SESSION["logged_user_role"])
                           {
                                case "Instructor":
                                    $personalPageLink="instructorPage.php";
                                    break;
                                case "Student":
                                    $personalPageLink="studentPage.php";
                                    break;
                           }
                           ?>
                           <li>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>
                            Welcome <b> <?php echo $_SESSION["logged_user_username"] ?> <span class="caret"></span></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo $personalPageLink; ?>">Personal</a></li>
                                <li><a href="changeInstructorPass.php">Change Password</a></li>
                            </ul>
                           </li>
                           <li>
                            <a href="logoutt.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
                           </li>
                           <?php
                        }
                        ?>
                    </ul>
                </div>
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>   
            </div>
        </nav>
        <div class="container">
            <div class="container-fluid">   
                <div class="row">
                    <form action="functions.php" method="post" role="form">
                        <div class="col-lg-12">
                            <div class="page-header">
                                <h2>Add Exam</h2>
                            </div>
                            <div class="card-view">
                                <div class="form-group">
                                    <label for="courseName">Exam Course: </label>
									<input type="hidden" class="form-control" name="courseName2" id="courseName2" value="<?php echo $selectedCourse;?>">
                                    <input readonly="readonly" class="form-control" name="courseName" value="<?php echo $selectedCourseName;?>"> 
                                </div>
                                <div class="form-group">
                                    <label for="examType">Exam Type: </label>
                                    <select class="form-control" name="examType" id="examType">
                                      <?php
                                        if($exam!=null)
                                        {
                                            while($row =mysqli_fetch_assoc($exam))
                                            {
                                                ?>
                                                <option
                                                       value="<?php echo $row["exam_id"];?>"><?php echo $row["exam_name"]; ?></option>
                                            <?php
                                            }
                                        }
                                        ?>  
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="questionNum">Question Number:</label>
                                    <input required type="text" class="form-control" name="questionNum" id="questionNum">
                                </div>
                                <div class="form-group">
                                    <label for="examQuestion">Question 1:</label>
                                    <textarea style="resize: vertical" class="form-control" name="examQuestion" id="examQuestion"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="examAns1">Answer 1:</label>
                                    <input required type="text" class="form-control" name="examAns1" id="examAns1">
                                </div>
                                <div class="form-group">
                                    <label for="examAns2">Answer 2:</label>
                                    <input required type="text" class="form-control" name="examAns2" id="examAns2">
                                </div>
                                <div class="form-group">
                                    <label for="examAns3">Answer 3:</label>
                                    <input required type="text" class="form-control" name="examAns3" id="examAns3">
                                </div>
                                <div class="form-group">
                                    <label for="examAns4">Answer 4:</label>
                                    <input required type="text" class="form-control" name="examAns4" id="examAns4">
                                </div>
                                <div class="form-group pull-right">
                                    <input type="submit" name="addQuestion" class="btn btn-primary"
                                           value="Add Question">
                                </div>
                            </div>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>