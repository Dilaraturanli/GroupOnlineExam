<?php 

include("database.php");
ob_start();
session_start();

$adminUserName = $_POST['adminUserName'];
$adminPassword = $_POST['adminPassword'];

$sql_check = mysql_query("select * from admininfo where admin_username='".$adminUserName."' and admin_password='".$adminPassword."' ") or die(mysql_error());

if(mysql_num_rows($sql_check))  {
    $_SESSION["login"] = "true";
    $_SESSION["name"] = $adminUserName;
    $_SESSION["pass"] = $adminPassword;
    header("Location:home_index.php");
}
else {
		echo "<center>Incorrect user name or password.<br><a href=login_index.php>Turn Back</a></center>";	
}

ob_end_flush();
?>