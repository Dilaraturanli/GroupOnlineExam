<?php
include "functions.php";
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <script src="js/jquery-1.12.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/exam.css">
    <title>Online Examination System</title>
</head>
<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#"> Online Examination Admin System</a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li class="active">
                    <a href="forgetPassword.php"><span class="glyphicon glyphicon-edit"></span> Forget Password? </a>
                </li>
                
            </ul>
        </div>
        </div>
    </nav>
<div class="container">
    <div class="container-fluid">
        <?php
        if(isset($_COOKIE['noUser']))
        {
            ?>
            <div class="alert alert-danger fade in">
                <a href='#' class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>User name or password is wrong.</strong>
            </div>
            <?php
        }
        ?>
        <?php
        if(isset($_COOKIE['emptyData']))
        {
            ?>
            <div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Please fill necessary fields.</strong>
            </div>
            <?php
        }
        ?>
        
        
<div class="row">
    <div class="col-lg-12 text-center">
        <div class="card-view">
            <form action="admin.php" method="post" role="form">
                <div class="form-group">
                    <label class="pull-left" for="adminUserName">Enter your User Name:</label>
                    <input type="text" required name="adminUserName" id="adminUserName" class="form-control">
                    
                    
                </div>
                <div class="form-group">
                    <label class="pull-left" for="adminPassword">Enter your Password:</label>
                    <input type="password" required name= "adminPassword" id="adminPassword" class="form-control">
                </div>
                <div class="form-group pull-right">
                    <input type="submit" name="tryLogin" class="btn btn-primary" value="Login">
                </div>
            </form>
        </div>
    </div>
</div>
</div>
</div>
        