<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>

<?php
if($_POST["deletestudent"]){
 $student=$_POST["student"];
 $length=count($student);
	
	   include("database.php"); 
     for($i=0; $i<$length;$i++){
	$student= mysql_query("DELETE FROM  user WHERE user_id=$student[$i]");
	 }
	 echo "<center><u><b>The student successfully deleted</b></u><br><a href=deletestudent_index.php>Turn Back</a></center>";
 }
	
  
 
 
?>