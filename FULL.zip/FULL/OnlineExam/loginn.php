<?php

$username = $userpassword= "";

if($_SERVER["REQUEST_METHOD"] =="POST" && isset($_POST["userName"]) && isset($_POST["userPassword"]) && isset($_POST["roleList"]) && !empty($_POST["userName"]) && !empty($_POST["userPassword"]))
   {
    
    $username=test_input($_POST["userName"]);
    $userpassword=test_input($_POST["userPassword"]);
    
    
    $roles = $_POST["roleList"];
    
    if($roles === 0)
    {
        header('Location: loginPage.php');
        
        exit();
    }
    
    
    $servername= "localhost:3306";
    $userName="root";
    $passWord="";
    $conn=mysqli_connect($servername, $userName, $passWord, "examonline");
    
    mysqli_set_charset($conn,'utf8');
    
    $sql = "SELECT u.user_username, u.user_password, r.role_name FROM user as u, role as r WHERE u.user_username='" . $username ."' AND u.user_password='" . $userpassword . "' AND u.user_role='" . $roles . "'AND u.user_role= r.role_id";
    $result= mysqli_query($conn, $sql);
    if(mysqli_num_rows($result)>0)
    {
        ob_start();
        session_start();
        $row=mysqli_fetch_assoc($result);
        $_SESSION["logged_user_username"] = $row["user_username"];
        $_SESSION["logged_user_password"] = $row["user_password"];
        $_SESSION["logged_user_role"] = $row["role_name"];
        if($_SESSION["logged_user_role"] === "Instructor")
        {
            header('Location: instructorPage.php');
        }
        elseif ($_SESSION["logged_user_role"]=== "Student")
        {
            header('Location: studentPage.php');
        }
        ob_end_flush();
    }
        else
        {
            header('Location: loginPage.php');
            setcookie("noUser","noUser", time() + (1));
        }
        $conn->close();
    
   }else
    {
     header('Location: loginPage.php');
     setcookie("emptyData","emptyData",time() + (1));
    }
    
function test_input($data)
    {
        $data=trim($data);
        $data=stripcslashes($data);
        $data=htmlspecialchars($data);
        return $data;
    }
