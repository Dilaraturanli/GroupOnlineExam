<?php
include "functions.php";
session_start();
if(isset($_SESSION["logged_user_role"]))
{
    switch($_SESSION["logged_user_role"])
    {
        case "Student":
            header('Location: mainPage.php');
            setcookie("forbiddenPage" , "forbiddenPage" , time() + (2));
            break;
    }
}
elseif(!isset($_SESSION["logged_user_role"]))
{
    header('Location: loginPage.php');
    setcookie("loginFirst" , "loginFirst" , time() + (2));
}



$myCourse=getStudentCourse($_SESSION["logged_user_username"]);

$exam=getExamName();
?>

<!DOCTYPE html>
<html>
<head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <script src="js/jquery-1.12.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery-ui.js"></script>
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/jquery-ui.css">
        <link rel="stylesheet" href="css/exam.css">
        <title>Online Exam System</title>
        <script>
        $(function () {
            $("#dateOfExam").datepicker({ minDate: 0 });
        });
    </script>
</head>
<body>
    <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Online Exam System</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="mainPage.php">MainPage</a></li>
                        <li><a href="courseInstructorPage.php">Courses</a></li>
						
                            
							
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <?php
                        if(isset($_SESSION["logged_user_username"]) && isset($_SESSION["logged_user_password"]) && isset($_SESSION["logged_user_role"]))
                        {
                           $personalPageLink="#";
                           switch ($_SESSION["logged_user_role"])
                           {
                                case "Instructor":
                                    $personalPageLink="instructorPage.php";
                                    break;
                                case "Student":
                                    $personalPageLink="studentPage.php";
                                    break;
                           }
                           ?>
                           <li>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>
                            Welcome <b> <?php echo $_SESSION["logged_user_username"] ?> <span class="caret"></span></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo $personalPageLink; ?>">Personal</a></li>
                                <li><a href="changeInstructorPass.php">Change Password</a></li>
                            </ul>
                           </li>
                           <li>
                            <a href="logoutt.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
                           </li>
                           <?php
                        }
                        ?>
                    </ul>
                </div>
                   
            </div>
        </nav>
    <div class="container">
        <div class="container-fluid">
            <div class="row">
                <form action="functions.php" method="POST" role="form">
                    <div class="col-lg-12 text-center">
                        <div class="page-header">
                            <h2>Create Exam</h2>
                        </div>
                        <div class="card-view">
                            
                            
                            <div class="form-group">
                                <label for="examNumNum">Exam Number: </label>
                                <input required type="text" class="form-control" name="examNumNum" id="examNumNum">
                            </div>
                            
                            <div class="form-group">
                                        <label for="dateOfExam">Date Of Exam: </label>
                                        <input type="date" required name="dateOfExam" id="dateOfExam" class="form-control" placeholder="Click for select date">
                                    </div>
                            <div class="form-group">
                                        <label for="startingTime">Starting Time: </label>
                                        <select class="form-control" name="startingTime" id="startingTime">
                                            <option value="9">09:00</option>
                                            <option value="11">11:00</option>
                                            <option value="13">13:00</option>
                                            <option value="15">15:00</option>
                                            <option value="17">17:00</option>
                                    
                                    
                                        </select>
                            </div>
                            <div class="form-group">
                                        <label for="finishingTime">Finishing Time: </label>
                                        <select class="form-control" name="finishingTime" id="finishingTime">
                                            <option value="1">11:00</option>
                                            <option value="3">13:00</option>
                                            <option value="5">15:00</option>
                                            <option value="7">17:00</option>
                                            <option value="9">19:00</option>
                                    
                                        </select>
                            </div>
                            <div class="form-group pull-right">
                                    <input type="submit" name="createExam" class="btn btn-primary"
                                           value="Create Exam">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
            
            
</body>
</html>