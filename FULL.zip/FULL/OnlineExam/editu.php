<?php 

include("database.php");
ob_start();
session_start();

if(!isset($_SESSION["login"])){
    header("Location:login_index.php");
}

?>

<?php
 include("database.php"); 

$userid=$_POST["userid"];
	 $username=$_POST["username"];
     $firstname=$_POST["firstname"];
	 $lastname=$_POST["lastname"];
	  $email=$_POST["email"];
	  $userrole=$_POST["userrole"];

	$s=mysql_query("UPDATE user SET user_username='$username' WHERE user_id=$userid");
	$s=mysql_query("UPDATE user SET  user_name='$firstname' WHERE user_id=$userid");
	$s=mysql_query("UPDATE user SET user_surname='$lastname' WHERE user_id=$userid");
	$s=mysql_query("UPDATE user SET user_email='$email' WHERE user_id=$userid");
	$s=mysql_query("UPDATE user SET user_role=$userrole WHERE user_id=$userid");
	
	

	echo "<center><u><b>The user successfully edited</b></u><br>
	
	<a href=edituser_index.php>Turn Back</a></center>";
  
 
 
?>



                